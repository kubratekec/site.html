// Kullanıcı verilerini localStorage'da saklama
const STORAGE_KEYS = {
    USERS: 'site_users',
    COMPLAINTS: 'site_complaints',
    CURRENT_USER: 'current_user'
};

// Demo kullanıcılar
const DEMO_USERS = [
    {
        id: 1,
        email: 'sakin@site.com',
        password: 'sakin123',
        name: 'Ahmet Yılmaz',
        role: 'Resident',
        block: 'A Blok',
        apartment: '12',
        phone: '0555 123 4567'
    },
    {
        id: 2,
        email: 'admin@site.com',
        password: 'admin123',
        name: 'Mehmet Demir',
        role: 'Admin',
        block: 'Yönetim',
        apartment: '-',
        phone: '0555 234 5678'
    },
    {
        id: 3,
        email: 'personel@site.com',
        password: 'personel123',
        name: 'Ali Kaya',
        role: 'Staff',
        block: 'Personel',
        apartment: '-',
        phone: '0555 345 6789'
    }
];

// Demo şikayetler
const DEMO_COMPLAINTS = [
    {
        id: 1,
        userId: 1,
        category: 'Asansör',
        title: 'B Blok Asansör Arızası',
        description: 'B blok asansörü çalışmıyor. Acil müdahale gerekiyor.',
        priority: 'High',
        status: 'In_Progress',
        block: 'B Blok',
        apartment: '5',
        createdAt: new Date('2024-01-15T10:30:00').toISOString(),
        updatedAt: new Date('2024-01-15T14:20:00').toISOString()
    },
    {
        id: 2,
        userId: 1,
        category: 'Temizlik',
        title: 'Bahçe Temizliği',
        description: 'Bahçede çöp birikmiş, temizlenmesi gerekiyor.',
        priority: 'Medium',
        status: 'Resolved',
        block: 'Ortak Alan',
        apartment: '-',
        createdAt: new Date('2024-01-10T08:15:00').toISOString(),
        updatedAt: new Date('2024-01-11T16:45:00').toISOString()
    }
];

// LocalStorage yardımcı fonksiyonlar
function initStorage() {
    if (!localStorage.getItem(STORAGE_KEYS.USERS)) {
        localStorage.setItem(STORAGE_KEYS.USERS, JSON.stringify(DEMO_USERS));
    }
    if (!localStorage.getItem(STORAGE_KEYS.COMPLAINTS)) {
        localStorage.setItem(STORAGE_KEYS.COMPLAINTS, JSON.stringify(DEMO_COMPLAINTS));
    }
}

function getUsers() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.USERS) || '[]');
}

function getComplaints() {
    return JSON.parse(localStorage.getItem(STORAGE_KEYS.COMPLAINTS) || '[]');
}

function saveComplaints(complaints) {
    localStorage.setItem(STORAGE_KEYS.COMPLAINTS, JSON.stringify(complaints));
}

function getCurrentUser() {
    const userStr = localStorage.getItem(STORAGE_KEYS.CURRENT_USER);
    return userStr ? JSON.parse(userStr) : null;
}

function setCurrentUser(user) {
    if (user) {
        localStorage.setItem(STORAGE_KEYS.CURRENT_USER, JSON.stringify(user));
    } else {
        localStorage.removeItem(STORAGE_KEYS.CURRENT_USER);
    }
}

// Sayfa yüklendiğinde
document.addEventListener('DOMContentLoaded', function() {
    initStorage();
    
    // Login sayfası kontrolü
    if (document.getElementById('loginForm')) {
        initLogin();
    }
    
    // Dashboard sayfası kontrolü
    if (document.getElementById('complaintForm')) {
        initDashboard();
    }
});

// Login işlevselliği
function initLogin() {
    const loginForm = document.getElementById('loginForm');
    
    loginForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        const email = document.getElementById('email').value;
        const password = document.getElementById('password').value;
        
        const users = getUsers();
        const user = users.find(u => u.email === email && u.password === password);
        
        if (user) {
            setCurrentUser(user);
            window.location.href = 'dashboard.html';
        } else {
            alert('E-posta veya şifre hatalı!');
        }
    });
}

// Dashboard işlevselliği
function initDashboard() {
    const currentUser = getCurrentUser();
    
    // Kullanıcı giriş yapmamışsa login sayfasına yönlendir
    if (!currentUser) {
        window.location.href = 'login.html';
        return;
    }
    
    // Kullanıcı bilgilerini göster
    document.getElementById('userName').textContent = currentUser.name;
    document.getElementById('userRole').textContent = getRoleText(currentUser.role);
    document.getElementById('welcomeName').textContent = currentUser.name;
    
    // Çıkış butonu
    document.getElementById('logoutBtn').addEventListener('click', function() {
        if (confirm('Çıkış yapmak istediğinize emin misiniz?')) {
            setCurrentUser(null);
            window.location.href = 'login.html';
        }
    });
    
    // Yeni şikayet butonu
    document.getElementById('newComplaintBtn').addEventListener('click', function() {
        document.getElementById('complaintModal').classList.add('active');
    });
    
    // Modal kapatma
    document.getElementById('closeModal').addEventListener('click', closeModal);
    document.getElementById('cancelComplaint').addEventListener('click', closeModal);
    
    // Modal dışına tıklanınca kapat
    document.getElementById('complaintModal').addEventListener('click', function(e) {
        if (e.target === this) {
            closeModal();
        }
    });
    
    // Şikayet formu
    const complaintForm = document.getElementById('complaintForm');
    complaintForm.addEventListener('submit', handleComplaintSubmit);
    
    // Fotoğraf önizleme
    const photoInput = document.getElementById('complaintPhoto');
    photoInput.addEventListener('change', handlePhotoPreview);
    
    // Filtre değişikliği
    document.getElementById('statusFilter').addEventListener('change', loadComplaints);
    
    // İstatistikleri yükle
    loadStats();
    
    // Şikayetleri yükle
    loadComplaints();
}

function closeModal() {
    document.getElementById('complaintModal').classList.remove('active');
    document.getElementById('complaintForm').reset();
    document.getElementById('photoPreview').classList.remove('active');
    document.getElementById('photoPreview').innerHTML = '';
}

function handlePhotoPreview(e) {
    const file = e.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const preview = document.getElementById('photoPreview');
            preview.innerHTML = `<img src="${e.target.result}" alt="Önizleme">`;
            preview.classList.add('active');
        };
        reader.readAsDataURL(file);
    }
}

function handleComplaintSubmit(e) {
    e.preventDefault();
    
    const currentUser = getCurrentUser();
    const complaints = getComplaints();
    
    const formData = new FormData(e.target);
    const newComplaint = {
        id: complaints.length > 0 ? Math.max(...complaints.map(c => c.id)) + 1 : 1,
        userId: currentUser.id,
        category: formData.get('category'),
        title: formData.get('title'),
        description: formData.get('description'),
        priority: formData.get('priority'),
        status: 'Open',
        block: formData.get('block') || currentUser.block || 'Belirtilmedi',
        apartment: formData.get('apartment') || currentUser.apartment || '-',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    
    complaints.push(newComplaint);
    saveComplaints(complaints);
    
    alert('Şikayetiniz başarıyla oluşturuldu!');
    closeModal();
    loadComplaints();
    loadStats();
}

function loadStats() {
    const currentUser = getCurrentUser();
    const complaints = getComplaints();
    const userComplaints = complaints.filter(c => c.userId === currentUser.id);
    
    const stats = {
        total: userComplaints.length,
        open: userComplaints.filter(c => c.status === 'Open' || c.status === 'Assigned' || c.status === 'In_Progress').length,
        resolved: userComplaints.filter(c => c.status === 'Resolved' || c.status === 'Closed').length,
        pending: userComplaints.filter(c => c.status === 'Pending').length
    };
    
    const statsGrid = document.getElementById('statsGrid');
    statsGrid.innerHTML = `
        <div class="stat-card">
            <h3>Toplam Şikayet</h3>
            <div class="stat-value">${stats.total}</div>
        </div>
        <div class="stat-card">
            <h3>Açık Şikayetler</h3>
            <div class="stat-value">${stats.open}</div>
        </div>
        <div class="stat-card">
            <h3>Çözülen</h3>
            <div class="stat-value">${stats.resolved}</div>
        </div>
        <div class="stat-card">
            <h3>Beklemede</h3>
            <div class="stat-value">${stats.pending}</div>
        </div>
    `;
}

function loadComplaints() {
    const currentUser = getCurrentUser();
    const complaints = getComplaints();
    const statusFilter = document.getElementById('statusFilter').value;
    
    let userComplaints = complaints.filter(c => c.userId === currentUser.id);
    
    if (statusFilter !== 'all') {
        userComplaints = userComplaints.filter(c => c.status === statusFilter);
    }
    
    // Tarihe göre sırala (en yeni önce)
    userComplaints.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    const complaintsList = document.getElementById('complaintsList');
    
    if (userComplaints.length === 0) {
        complaintsList.innerHTML = `
            <div class="empty-state">
                <svg viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <path d="M9 12H15M9 16H15M17 21H7C5.89543 21 5 20.1046 5 19V5C5 3.89543 5.89543 3 7 3H12.5858C12.851 3 13.1054 3.10536 13.2929 3.29289L18.7071 8.70711C18.8946 8.89464 19 9.149 19 9.41421V19C19 20.1046 18.1046 21 17 21Z" stroke="currentColor" stroke-width="2" stroke-linecap="round"/>
                </svg>
                <h3>Henüz şikayet bulunmuyor</h3>
                <p>Yeni bir şikayet oluşturmak için yukarıdaki butonu kullanın</p>
            </div>
        `;
        return;
    }
    
    complaintsList.innerHTML = userComplaints.map(complaint => `
        <div class="complaint-card">
            <div class="complaint-header">
                <div>
                    <div class="complaint-title">${escapeHtml(complaint.title)}</div>
                    <div class="complaint-meta">
                        <span>📁 ${escapeHtml(complaint.category)}</span>
                        <span>📍 ${escapeHtml(complaint.block)} ${escapeHtml(complaint.apartment)}</span>
                        <span>📅 ${formatDate(complaint.createdAt)}</span>
                    </div>
                </div>
                <div>
                    <span class="status-badge status-${complaint.status}">${getStatusText(complaint.status)}</span>
                </div>
            </div>
            <div class="complaint-description">${escapeHtml(complaint.description)}</div>
            <div class="complaint-footer">
                <div>
                    <span class="priority-badge priority-${complaint.priority}">${getPriorityText(complaint.priority)}</span>
                </div>
                <div style="color: var(--text-muted); font-size: 12px;">
                    Son güncelleme: ${formatDate(complaint.updatedAt)}
                </div>
            </div>
        </div>
    `).join('');
}

function getRoleText(role) {
    const roles = {
        'Admin': 'Yönetici',
        'Staff': 'Personel',
        'Resident': 'Site Sakini'
    };
    return roles[role] || role;
}

function getStatusText(status) {
    const statuses = {
        'Open': 'Yeni',
        'Assigned': 'Atandı',
        'In_Progress': 'İşlemde',
        'Pending': 'Beklemede',
        'Resolved': 'Çözüldü',
        'Closed': 'Kapatıldı'
    };
    return statuses[status] || status;
}

function getPriorityText(priority) {
    const priorities = {
        'Low': 'Düşük',
        'Medium': 'Orta',
        'High': 'Yüksek',
        'Critical': 'Kritik'
    };
    return priorities[priority] || priority;
}

function formatDate(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now - date;
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    
    if (days === 0) {
        const hours = Math.floor(diff / (1000 * 60 * 60));
        if (hours === 0) {
            const minutes = Math.floor(diff / (1000 * 60));
            return `${minutes} dakika önce`;
        }
        return `${hours} saat önce`;
    } else if (days === 1) {
        return 'Dün';
    } else if (days < 7) {
        return `${days} gün önce`;
    } else {
        return date.toLocaleDateString('tr-TR', {
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
    }
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}