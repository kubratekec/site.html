# Site İstek & Şikayet Yönetim Sistemi

Site sakinleri için talep ve şikayet yönetim sistemi.

## 📁 Proje Yapısı

```
cursor/
├── index.html          # Ana sayfa (login'e yönlendirir)
├── login.html          # Giriş sayfası
├── dashboard.html      # Ana dashboard (giriş sonrası)
├── style.css           # Stil dosyası
├── script.js           # JavaScript işlevleri
└── README.md           # Bu dosya
```

## 🚀 Kullanım

1. `index.html` veya `login.html` dosyasını tarayıcıda açın
2. Demo hesaplardan biriyle giriş yapın
3. Şikayet oluşturun ve yönetin

## 👤 Demo Hesaplar

- **Site Sakini:** `sakin@site.com` / `sakin123`
- **Yönetici:** `admin@site.com` / `admin123`
- **Personel:** `personel@site.com` / `personel123`

## ✨ Özellikler

- ✅ Kullanıcı girişi
- ✅ Şikayet oluşturma
- ✅ Şikayet listeleme ve filtreleme
- ✅ İstatistikler
- ✅ Responsive tasarım
- ✅ LocalStorage ile veri saklama

## 🛠️ Teknolojiler

- HTML5
- CSS3
- JavaScript (Vanilla)
- LocalStorage API

## 📝 Notlar

- Tüm veriler tarayıcınızın localStorage'ında saklanır
- Sayfa yenilendiğinde veriler korunur
- Mobil uyumlu responsive tasarım
